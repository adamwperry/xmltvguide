namespace xmlTVGuide.Models;

public class ChannelMapDto
{
    public string? Name { get; set; }
    public string? ChannelId { get; set; }
}

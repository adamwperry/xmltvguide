using System;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using xmlTVGuide.Services;

namespace xmlTVGuide;

class Program
{
    static async Task Main(string[] args)
    {
        try
        {
            // if (args.Contains("--help"))
            // {
            //     Console.WriteLine("Usage:");
            //     Console.WriteLine("  --fake               Use fake data for testing.");
            //     Console.WriteLine("  --channelmap=<path>  Specify the path to the channel map JSON file.");
            //     Console.WriteLine("  --url=<url>          Specify the URL or file path for the data source.");
            //     Console.WriteLine("  --output=<path>      Specify the output path for the generated XML file.");
            //     Console.WriteLine("  --help               Display this help message.");
            //     return;
            // }

            // var fake = args.Contains("--fake");

            // var urlArg = args.FirstOrDefault(arg => arg.StartsWith("--url="));
            // var url = !string.IsNullOrEmpty(urlArg)
            //     ? urlArg.Substring("--url=".Length)
            //     : Environment.GetEnvironmentVariable("EPG_URL") ?? string.Empty;

            // var mapArg = args.FirstOrDefault(a => a.StartsWith("--channelmap=", StringComparison.OrdinalIgnoreCase));
            // var channelMapPath = !string.IsNullOrEmpty(mapArg)
            //     ? mapArg.Substring("--channelmap=".Length)
            //     : Environment.GetEnvironmentVariable("CHANNEL_MAP_PATH") ?? string.Empty;

            // var outputArg = args.FirstOrDefault(arg => arg.StartsWith("--output="));
            // var outputPath = outputArg != null
            //     ? outputArg.Substring("--output=".Length)
            //     : Path.Combine(Directory.GetCurrentDirectory(), "output", "guide.xml");
            var (fake, url, channelMapPath, outputPath) = ParseArguments(args);

            var serviceCollection = new ServiceCollection();
            serviceCollection.AddSingleton<IXmlTVBuilder, XmlTVBuilder>();

            IDataFetcher dataFetcherService = null;
            if (fake)
            {
                url = fake && url.Length == 0 ? Path.Combine(Directory.GetCurrentDirectory(), "src", "TestData", "tvguide.json") : url;
                serviceCollection.AddSingleton<IDataFetcher, FakeDataFetcher>();
            }
            else
            {
                if(url.Length == 0)
                {
                    Console.WriteLine("Please provide a URL using --url=<url>.");
                    return;
                }
                serviceCollection.AddSingleton<IDataFetcher, DataFetcher>();
            }

            var serviceProvider = serviceCollection.BuildServiceProvider();
            dataFetcherService = serviceProvider.GetService<IDataFetcher>();
            var xmlTVBuilderService = serviceProvider.GetService<IXmlTVBuilder>();

            var data = await dataFetcherService.FetchDataAsync(url);

            JsonObject epgData;
            try 
            {
                epgData = JsonNode.Parse(data)?.AsObject()
                    ?? throw new Exception("Invalid JSON structure");
            }
            catch (JsonException ex)
            {
                Console.WriteLine($"Failed to parse JSON data: {ex.Message}");
                Environment.Exit(1);
                return;
            }
  
            xmlTVBuilderService.BuildXmlTV(epgData, channelMapPath, outputPath);
            Console.WriteLine("XML guide.xml has been generated successfully.");
            Environment.Exit(0);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"An error occurred: {ex.Message}");
            Environment.Exit(1);
        }
    }

    private static (bool fake, string url, string channelMapPath, string outputPath) ParseArguments(string[] args)
    {
        if (args.Contains("--help"))
        {
            Console.WriteLine("Usage:");
            Console.WriteLine("  --fake               Use fake data for testing.");
            Console.WriteLine("  --channelmap=<path>  Specify the path to the channel map JSON file.");
            Console.WriteLine("  --url=<url>          Specify the URL or file path for the data source.");
            Console.WriteLine("  --output=<path>      Specify the output path for the generated XML file.");
            Console.WriteLine("  --help               Display this help message.");
            Environment.Exit(0);
        }

        var fake = args.Contains("--fake");

        var urlArg = args.FirstOrDefault(arg => arg.StartsWith("--url="));
        var url = !string.IsNullOrEmpty(urlArg)
            ? urlArg.Substring("--url=".Length)
            : Environment.GetEnvironmentVariable("EPG_URL") ?? string.Empty;

        var mapArg = args.FirstOrDefault(a => a.StartsWith("--channelmap=", StringComparison.OrdinalIgnoreCase));
        var channelMapPath = !string.IsNullOrEmpty(mapArg)
            ? mapArg.Substring("--channelmap=".Length)
            : Environment.GetEnvironmentVariable("CHANNEL_MAP_PATH") ?? string.Empty;

        var outputArg = args.FirstOrDefault(arg => arg.StartsWith("--output="));
        var outputPath = outputArg != null
            ? outputArg.Substring("--output=".Length)
            : Path.Combine(Directory.GetCurrentDirectory(), "output", "guide.xml");

        return (fake, url, channelMapPath, outputPath);
    }
}

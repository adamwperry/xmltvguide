using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Xml.Linq;
using xmlTVGuide.Models;


namespace xmlTVGuide.Services;

public interface IXmlTVBuilder
{
    void BuildXmlTV(JsonObject epgData, string channelMapPath, string outputPath);
}

public class XmlTVBuilder : IXmlTVBuilder
{
    public void BuildXmlTV(JsonObject epgData, string channelMapPath, string outputPath)
    {
        if (epgData == null)
            throw new ArgumentNullException(nameof(epgData), "EPG data cannot be null.");
        
        if (string.IsNullOrWhiteSpace(outputPath))
            throw new ArgumentException("Output path cannot be null or empty.", nameof(outputPath));

        var channelMap = string.IsNullOrWhiteSpace(channelMapPath)
            ? null
            : LoadChannelMap(channelMapPath);
    
        var tv = new XElement("tv");

        var sortedChannels = epgData["channels"]?.AsArray()
            ?.OrderBy(c => c?["callSign"]?.ToString() ?? "")
            ?? Enumerable.Empty<JsonNode>();

        foreach (var channel in sortedChannels ?? Enumerable.Empty<JsonNode>())
        {
            var id = channel["channelId"]?.ToString() ?? null;
            var name = channel["callSign"]?.ToString() ?? null;
            var number = channel["channelNo"]?.ToString() ?? null;
            var thumb = channel["thumbnail"]?.ToString() ?? null;

            if (id == null || name == null) continue;

            
            var mappedChannel = channelMap?.FirstOrDefault(map => map.ChannelId == id);
            if (mappedChannel != null)
            {
                name = mappedChannel.Name;
                // number = mappedChannel.ChannelId;
            } 
            else 
            {
                name = $"{number.Trim()} {name.Trim()}".Trim();
            }
        

            var chan = new XElement("channel", new XAttribute("id", id));
            chan.Add(new XElement("display-name", $"{name}".Trim()));

            if (!string.IsNullOrWhiteSpace(thumb))
            {
                var logoUrl = thumb.StartsWith("http") ? thumb : $"https://{thumb.TrimStart('/')}";
                chan.Add(new XElement("icon", new XAttribute("src", logoUrl)));
            }

 
            tv.Add(chan);

            foreach (var ev in channel["events"]?.AsArray() ?? Enumerable.Empty<JsonNode>())
            {
                var start = FormatTime(ev["startTime"]?.ToString());
                var stop = FormatTime(ev["endTime"]?.ToString());
                var title = ev["program"]?["title"]?.ToString();
                var desc = ev["program"]?["shortDesc"]?.ToString();

                if (start == null || stop == null || title == null) continue;

                var programme = new XElement("programme",
                    new XAttribute("start", start),
                    new XAttribute("stop", stop),
                    new XAttribute("channel", id));

                programme.Add(new XElement("title", new XAttribute("lang", "en"), title));
                if (!string.IsNullOrWhiteSpace(desc))
                    programme.Add(new XElement("desc", new XAttribute("lang", "en"), desc));

                tv.Add(programme);
            }
        }

        SaveXmlToFile(tv, outputPath);
    }

    private void SaveXmlToFile(XElement tv, string outputPath)
    {
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(outputPath)!);
            new XDocument(new XDeclaration("1.0", "utf-8", "yes"), tv).Save(outputPath);
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException($"Failed to save XML to file: {outputPath}. Error: {ex.Message}", ex);
        }
    }

private List<ChannelMapDto> LoadChannelMap(string filePath)
{
    if (string.IsNullOrWhiteSpace(filePath))
        throw new ArgumentException("File path cannot be null or empty.", nameof(filePath));

    if (!File.Exists(filePath))
        throw new FileNotFoundException("Channel map file not found.", filePath);

    try
    {
        var jsonContent = File.ReadAllText(filePath);
        var root = JsonNode.Parse(jsonContent)?.AsObject()
                   ?? throw new InvalidOperationException("Invalid JSON format: expected an object.");

        var jsonArray = root["channels"]?.AsArray()
                         ?? throw new InvalidOperationException("Missing 'channels' array in JSON file.");

        return jsonArray
            .Select(node => new ChannelMapDto
            {
                Name = node?["channel"]?["name"]?.ToString(),
                ChannelId = node?["channel"]?["channelId"]?.ToString()
            })
            .Where(dto => dto.Name != null && dto.ChannelId != null)
            .ToList();
    }
    catch (Exception ex)
    {
        throw new InvalidOperationException($"Failed to load channel map from file: {filePath}. Error: {ex.Message}", ex);
    }
}


    private string? FormatTime(string? iso) =>
        DateTime.TryParse(iso, out var dt)
            ? dt.ToUniversalTime().ToString("yyyyMMddHHmmss") + " +0000"
            : null;

}

using System;
using System.Threading.Tasks;
using xmlTVGuide.Utilities;

namespace xmlTVGuide.Services;

public class DataFetcher : DataFetcherBase
{
    public override async Task<string> FetchDataAsync(string url)
    {

        url = SetUnixTime(url);

        var client = await GetClientAsync(UserAgent.Chrome);
        var response = await client.GetAsync(url);

        if (response.IsSuccessStatusCode)
            return await response.Content.ReadAsStringAsync();
        else
            throw new Exception($"Failed to fetch data from {url}. Status code: {response.StatusCode}");
    }


    public string SetUnixTime(string url)
    {
        var unixTime = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
        return url.Replace("{unixtime}", unixTime.ToString());
    }
}

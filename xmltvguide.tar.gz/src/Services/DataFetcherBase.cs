using System.Net.Http;
using System.Threading.Tasks;
using xmlTVGuide.Utilities;

namespace xmlTVGuide.Services;


public abstract class DataFetcherBase : IDataFetcher
{
    public abstract Task<string> FetchDataAsync(string url);

    protected Task<HttpClient> GetClientAsync(UserAgent userAgent)
    {
        var client = new HttpClient();
        client.DefaultRequestHeaders.Add("User-Agent", userAgent.Value);

        client.DefaultRequestHeaders.Add("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8");
        client.DefaultRequestHeaders.Add("Accept-Language", "en-US,en;q=0.5");
        client.DefaultRequestHeaders.Add("Connection", "keep-alive");

        return Task.FromResult(client);
    }
}
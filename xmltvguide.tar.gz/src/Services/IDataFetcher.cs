using System;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;
using xmlTVGuide.Utilities;

namespace xmlTVGuide.Services;


public interface IDataFetcher
{
    Task<string> FetchDataAsync(string url);
}




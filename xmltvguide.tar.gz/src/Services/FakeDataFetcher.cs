using System.IO;
using System.Threading.Tasks;

namespace xmlTVGuide.Services;


public class FakeDataFetcher : DataFetcherBase
{
    public override Task<string> FetchDataAsync(string url)
    {
        if (!File.Exists(url))
            throw new FileNotFoundException("The file 'url' does not exist.");

        string content = File.ReadAllText(url);
        return Task.FromResult(content);
    }
}